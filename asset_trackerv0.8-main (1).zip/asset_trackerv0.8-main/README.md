JavaFX Project for asset tracking.
